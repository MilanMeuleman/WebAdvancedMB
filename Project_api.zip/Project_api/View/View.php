<?php
namespace View;
interface View
{
public function show(array $data);
}